module.exports = {
  components: {
    'MedicineRetrieval' : require('./custom_component/medicine/medicine_retrieval'),

    'FAQRetrieval' : require('./custom_component/faq/faq_keyword_retrieval'),
    'FAQServiceRetrieval' : require('./custom_component/faq/faq_sentence_retrieval'),

    'FindHospitalRetrieval' : require('./custom_component/professor_retrieval/with_disease'),
    'ProfessorInDeptRetrieval' : require('./custom_component/professor_retrieval/with_department'),
    'FindProfessorRetrieval' : require('./custom_component/professor_retrieval/with_professor_name'),
    'SetProfessorInDept' : require('./custom_component/professor_retrieval/setProfessorInDept'),
    'SetProfessorInOther' : require('./custom_component/professor_retrieval/setProfessorInOther'),

    'StartServiceRetrieval' : require('./custom_component/start_end/start_chat'),
    'UndefinedServiceRetrieval' : require('./custom_component/start_end/unresolved'),
    
    'MakeReservationInOther' : require('./custom_component/reservation/makeReservationInOther'),
    'MakeReservation' : require('./custom_component/reservation/make_reservation'),
    'DeleteReservation' : require('./custom_component/reservation/delete_reservation'),
    'ShowReservation' : require('./custom_component/reservation/show_reservation')
  }
};

