"use strict"

var express = require("express");
var mysql = require('mysql');
var FBTemplate = require('../../FacebookTemplate.js')
var database = require('../../mysql_pool/pool.js');


var FAQ_arr = [];
var searching_FAQ = '';

function hitQuery(FAQ_question) {
    return new Promise((resolve, reject) => {
        var sql = 'SELECT * FROM faq WHERE question like ' + "'%" + FAQ_question + "%'";
        
        database.getPool((err, con) => {
            if (err) {
                // Code handing connection error...
            }

            con.query(sql, (err, rows) => {
                if (err) {
                    reject(new Error(err));
                }
                else {
                    FAQ_arr = rows;

                    resolve();
                }
            });
        })
    });
}

module.exports = {

    metadata: () => ({
        "name": "FAQRetrieval",
        "properties": {
            "Questions": { "type": "string", "required": true }
        },
        "supportedActions": []
    }),

    invoke: (conversation, done) => {
        var FAQ_question = conversation.messagePayload().text;

        var promise = hitQuery(FAQ_question).then(() => {
            if (FAQ_arr.length == 1) {
                conversation.reply({ text: '[질문]\n' + FAQ_arr[0].Question + '\n' });

                if (FAQ_arr[0].Answer != null)
                    conversation.reply({ text: '[답변]\n' + FAQ_arr[0].Answer + '\n' });
            }
            else {
                conversation.reply({ text: FAQ_arr.length + '개의 관련 질문이 있어요.' });

                var inner = []
                for (var i = 0; i < FAQ_arr.length;) {
                    var hospital_imgurl = 'http://storage.iseverance.com/2013_obj_sev/top/logo_severance.gif';
                    inner.push(FBTemplate.listInnerFBT(FAQ_arr[i].Question, FAQ_arr[i].Answer, FAQ_arr[i].url));
                    i++;
                    if (i == FAQ_arr.length - 1 | (i % 4 == 0 && i != 0)) {
                        conversation.reply(FBTemplate.listFBT(inner));
                        inner = [];
                    }
                }
            }

            conversation.transition();
            done();

        }).catch(err => {
            conversation.reply({ text: '요청하신 ' + FAQ_question + '의 정보를 가져오지 못했어요. 죄송해요 :(' });

            conversation.transition();
            done();
        })
    }
};

