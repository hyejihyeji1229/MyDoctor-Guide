"use strict"

var FBTemplate = require('../../FacebookTemplate.js')
var express = require('express');
var mysql = require('mysql');
var database = require('../../mysql_pool/pool.js');



var faqData = [];
function hitQuery(faqIndex) {
    return new Promise((resolve, reject) => {
        var sql = 'SELECT * FROM faq WHERE id=' + faqIndex;

        database.getPool((err, con) => {
            if (err) { }

            con.query(sql, (err, rows) => {
                if (err) {
                    reject(Error(err));
                }
                else {
                    faqData = rows;

                    resolve();
                }
            });
        });
    });
}

module.exports = {
    metadata: () => ({
        "name": "FAQServiceRetrieval",
        "properties": {
            "faqQuestions": { "type": "string", "required": true }
        },
        "supportedActions": []
    }),

    invoke: (conversation, done) => {
        var faq_string = '' + conversation.nlpResult().intentMatches()[0].intent;
        var faq_index = faq_string.slice(3);

        var promise = hitQuery(faq_index).then(() => {
            conversation.reply({
                text: 'Q: ' + faqData[0].Question
            });
            conversation.reply({
                text: 'A: ' + faqData[0].Answer
            });

            conversation.transition();
            done();
        }).catch(err => {
            conversation.reply({
                text: '실패'
            });

            conversation.transition();
            done();
        })
    }
}