"use strict"

var express = require('express');
var mysql = require('mysql');
var database = require('../../mysql_pool/pool.js');

function setReservation(user_id, doctor, dept, date, name, phone) {
    return new Promise((resolve, reject) => {
        var sql = 'INSERT INTO reservation (user_id, prof_id, dept_id, date, name, phone) VALUES (\'' + user_id + '\',(select p.id from professors p where p.name= \'' + doctor + '\'),' + dept + ',\'' + date + '\',\'' + name + '\',\'' + phone + '\');';

        database.getConnection((err, con) => {
            if (err) {
            }

            con.query(sql, (err, rows) => {
                if (err) {
                    reject(Error(err));
                }
                else {
                    resolve();
                }
                // con.release();
            });

        });
    });
}

module.exports = {
    metadata: () => ({
        "name": "MakeReservationInOther",
        "properties": {
            "reservationDate": { "type": "string", "required": true },
            "professorName": { "type": "string", "required": true },
            "subjectName": { "type": "string", "required": true },
            "diseaseName": { "type": "string", "required": true },
            "userName": { "type": "string", "required": true },
            "userPhone": { "type": "string", "required": true }
        },
        "supportedActions": []
    }),

    invoke: (conversation, done) => {
        // 'mm/dd/yyyy hh:mm AM'
        var date = conversation.properties().reservationDate;
        var prof_name = conversation.properties().professorName;
        var dept_name = conversation.properties().subjectName;
        var dis_name = conversation.properties().diseaseName;
        var user_name = conversation.properties().userName;
        var user_phone = conversation.properties().userPhone;

        var user_id = conversation.userId();

        conversation.variable("isReservation", "false"); //예약 플로우를 초기상태로

        var promise = setReservation(user_id, prof_name, dept_name, date, user_name, user_phone).then(() => {
            conversation.reply({ text: '예약이 완료되었습니다.' });
            // 대화를 다시 돌림
            conversation.transition();
            done();
        }).catch(err => {
            conversation.reply({ text: '예약에 실패했습니다....' + err });

            conversation.transition();
            done();
        });


    }
}