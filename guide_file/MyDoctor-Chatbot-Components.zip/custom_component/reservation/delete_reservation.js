"use strict"

var express = require("express");
var mysql = require('mysql');
var database = require('../../mysql_pool/pool.js');


var show_arr = [];

function hitQuery(user_id) {

    return new Promise((resolve, reject) => {
        var sql = 'delete from reservation where user_id = ' + user_id + ';'

        database.getPool((err, con) => {
            if (err) { }

            con.query(sql, (err, result) => {
                if (err) {
                    reject(Error(err));
                }
                else {
                    show_arr = result;
                    resolve();
                }
            })
        });
    });
}

module.exports = {

    metadata: () => ({
        "name": "DeleteReservation",
        "properties": {
            "delete": { "type": "string", "required": true }
        },
        "supportedActions": []
    }),

    invoke: (conversation, done) => {
        // var _show_arr = [];
        var user_id = conversation.userId();

        var promise = hitQuery(user_id).then(() => {
            if (show_arr.affectedRows == 0) {
                conversation.reply({ text: '예약 된게 없습니다.\n' });
            }
            else {
                conversation.reply({ text: '예약 취소완료.\n' });
            }

            conversation.transition();
            done();
        }).catch(err => {
            conversation.reply({ text: '에러 발생.' });

            conversation.transition();
            done();
        })
    }
};

