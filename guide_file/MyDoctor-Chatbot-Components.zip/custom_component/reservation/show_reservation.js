"use strict"

var express = require("express");
var mysql = require('mysql');
var database = require('../../mysql_pool/pool.js');


var show_arr = [];

function hitQuery(user_id) {
    return new Promise((resolve, reject) => {
        var sql = 'select r.name as u_name, (select d.name from department d where d.id= r.dept_id) as d_name, (select p.name from professors p where p.id= r.prof_id) as p_name, r.date from reservation r where r.user_id =' + user_id + ';';

        database.getPool((err, con) => {
            if (err) { }

            con.query(sql, (err, rows) => {
                if (err) {
                    reject(Error(err));
                }
                else {
                    show_arr = rows;
                    resolve();
                }
            });
        });
    });
}

module.exports = {

    metadata: () => ({
        "name": "ShowReservation",
        "properties": {
            "show": { "type": "string", "required": true }
        },
        "supportedActions": []
    }),

    invoke: (conversation, done) => {
        var user_id = conversation.userId();

        var promise = hitQuery(user_id).then(() => {
            conversation.reply({ text: show_arr[0].u_name + '님께서는 ' + show_arr[0].d_name + show_arr[0].p_name + '교수님으로 \n' + show_arr[0].date + '에 예약 되셨습니다.\n' });

            conversation.transition();
            done();
        }).catch(err => {
            conversation.reply({ text: '예약 된게 없습니다.' });

            conversation.transition();
            done();
        })
    }
};

