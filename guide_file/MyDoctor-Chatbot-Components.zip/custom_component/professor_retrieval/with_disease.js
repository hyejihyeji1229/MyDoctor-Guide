"use strict"

var FBTemplate = require('../../FacebookTemplate.js')
var express = require("express");
var mysql = require('mysql');
var database = require('../../mysql_pool/pool.js');


var Hospital_arr = [];
var searching_Hospital = '';

function hitQuery(disease_name) {
    return new Promise((resolve, reject) => {
        var sql = 'SELECT * FROM professors WHERE major like ' + "'%" + disease_name + "%'";

        database.getPool((err, con) => {
            if (err) {
                // Code handilng connection err...
            }

            con.query(sql, (err, rows) => {
                if (err) {
                    reject(Error(err));
                }
                else {
                    Hospital_arr = rows;

                    resolve();
                }
            });
        })
    });

}

module.exports = {

    metadata: () => ({
        "name": "FindHospitalRetrieval",
        "properties": {
            "disease": { "type": "string", "required": true }
        },
        "supportedActions": []
    }),

    invoke: (conversation, done) => {
        var disease_name = conversation.messagePayload().text;
        var promise = hitQuery(disease_name).then(() => {
            
            if (Hospital_arr.length == 1) {
                conversation.reply({ text: disease_name + '을 진료하는 의사를 추천해드릴게요' });
                conversation.reply(FBTemplate.genericTwopayFBT(Hospital_arr[0].pimg, Hospital_arr[0].name, Hospital_arr[0].major, '자세히 보기', Hospital_arr[0].purl, '예약하기', Hospital_arr[0].dept_id + ',' + Hospital_arr[0].name));

            }
            else {
                conversation.reply({ text: Hospital_arr.length + '명의 담당 교수님이 있습니다.' });

                var inner = []
                for (var i = 0; i < Hospital_arr.length;) {
                    if (Hospital_arr[i].imageurl != 'undefined')
                        inner.push(FBTemplate.genrInnerTwopayFBT(Hospital_arr[i].pimg, Hospital_arr[i].name, Hospital_arr[i].major, '자세히 보기', Hospital_arr[i].purl, '예약하기', Hospital_arr[i].dept_id + ',' + Hospital_arr[i].name));
                    i++;
                    if (i == Hospital_arr.length | i == 10)
                        conversation.reply(FBTemplate.cardFBT(inner));
                }
                //conversation.reply({ text: '예약을 진행하시겠어요?' });


            }

            conversation.reply({ text: '예약을 진행하시겠어요? \n예약하시려면 예약하기 버튼을 눌러주세요:)' });

            conversation.transition();
            done();

        }).catch(err => {
            conversation.reply({ text: '요청하신 ' + disease_name + '의 정보를 가져오지 못했어요. 죄송해요ㅠ' });

            conversation.transition();
            done();
        });


    }
};

