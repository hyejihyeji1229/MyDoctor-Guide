"use strict"

var FBTemplate = require('../../FacebookTemplate.js')
var express = require("express");
var mysql = require('mysql');
var database = require('../../mysql_pool/pool.js');


var Hospital_arr = [];
var searching_Hospital = '';

function hitQuery(dept_name) {
    return new Promise((resolve, reject) => {
        var sql = 'SELECT * FROM professors WHERE dept_id = (SELECT id FROM department WHERE name like ' + "'%" + dept_name + "%'" + ')';
        database.getPool((err, con) => {
            if (err) { }

            con.query(sql, (err, rows) => {
                if (err) {
                    reject(Error(err));
                }
                else {
                    Hospital_arr = rows;

                    resolve();
                }
            });
        });
    });

}

module.exports = {

    metadata: () => ({
        "name": "ProfessorInDeptRetrieval",
        "properties": {
            "professor_result": { "type": "string", "required": true }
        },
        "supportedActions": []
    }),

    invoke: (conversation, done) => {
        var dept_name = '';
        // @TODO: try catch 문 ifelse 로 바꾸기
        try {
            //System.List 진료과 버튼 클릭 받아오기 
            dept_name = conversation.messagePayload().postback.action;

        } catch (e) {
            //사용자가 직접 진료과를 입력
            dept_name = conversation.messagePayload().text;
        }


        conversation.variable("subjectName", dept_name);
        var promise = hitQuery(dept_name).then(() => {

            if (Hospital_arr.length == 1) {
                conversation.reply(FBTemplate.genericTwoFBT(Hospital_arr[0].pimg, Hospital_arr[0].name, Hospital_arr[0].major, '자세히 보기', Hospital_arr[0].purl, '예약하기'));
            }
            else {
                conversation.reply({ text: Hospital_arr.length + '명의 의료진이 기다리고 있습니다!\n선택해주세요 B)' });

                var inner = []
                for (var i = 0; i < Hospital_arr.length;) {

                    if (Hospital_arr[i].imageurl != 'undefined') {
                        inner.push(FBTemplate.genrInnerTwoFBT(Hospital_arr[i].pimg, Hospital_arr[i].name, Hospital_arr[i].major, '자세히 보기', Hospital_arr[i].purl, '예약하기'));

                        if (i == 9) { break; } //10명이상이면 더보기 버튼 or 대화로 의료진 리스트 링크 줌. 

                    }

                    i++;
                }

                conversation.reply(FBTemplate.cardFBT(inner));
            }

            conversation.transition();
            done();

        }).catch(err => {
            conversation.reply({ text: '요청하신 ' + dept_name + '의 정보를 가져오지 못했어요. 죄송해요 :(' });

            conversation.transition();
            done();
        });
    }
};