// import { stringify } from "querystring";
"use strict"

var hanguler = require('../../hangul_processing/hanguler.js');
var FBTemplate = require('../../FacebookTemplate.js')
var express = require("express");
var mysql = require('mysql');
var database = require('../../mysql_pool/pool.js');


var medicine_arr = [];
var searching_medicine = '';

function hitQuery(generalName) {
    return new Promise((resolve, reject) => {
        var sql = 'SELECT * FROM medicine_list WHERE generalname like ' + "'%" + generalName + "%'";

        database.getPool((err, con) => {
            if (err) { }

            con.query(sql, (err, rows) => {
                if (err) {
                    reject(Error(err));
                }
                else {
                    medicine_arr = rows;

                    resolve();
                }
            });

        })

    });

}

module.exports = {

    metadata: () => ({
        "name": "MedicineRetrieval",
        "properties": {
            "lastQuestion": { "type": "string", "required": true }
        },
        "supportedActions": []
    }),

    invoke: (conversation, done) => {
        var medicineName = conversation.messagePayload().text;
        var generalName = hanguler.hanguler(medicineName);
        var promise = hitQuery(generalName).then(() => {
            if (medicine_arr.length == 1) {
                conversation.reply({ text: '[효능효과]\n' + medicine_arr[0].efficacy + '\n' });
                conversation.reply({ text: '[용법용량]\n' + medicine_arr[0].howtouse + '\n' });
                conversation.reply({ text: '[주의사항]\n' + medicine_arr[0].precaution });
                conversation.reply(FBTemplate.genericFBT(medicine_arr[0].imageurl, medicine_arr[0].name, medicine_arr[0].efficacy, '자세히 보기', medicine_arr[0].url));

            }
            else {
                conversation.reply({ text: medicine_arr.length + '개의 약이있어요.' });

                var inner = []
                for (var i = 0; i < medicine_arr.length;) {
                    if (medicine_arr[i].imageurl != 'undefined')
                        inner.push(FBTemplate.genrInnerFBT(medicine_arr[i].imageurl, medicine_arr[i].name, medicine_arr[i].efficacy, '자세히 보기', medicine_arr[i].url));
                    i++;
                    if (i == medicine_arr.length | i == 10)
                        conversation.reply(FBTemplate.cardFBT(inner));
                }
            }

            conversation.transition();
            done();

        }).catch(err => {
            conversation.reply({ text: '요청하신 ' + medicineName + '의 정보를 가져오지 못했어요. 죄송해요ㅠ' });

            conversation.transition();
            done();
        });


    }
};
