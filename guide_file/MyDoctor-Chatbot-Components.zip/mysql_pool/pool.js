"use strict"

var mysql = require('mysql');
var express = require("express");

// database metadata
var pool = mysql.createPool({
    connectionLimit: 100,
    host: 'localhost',
    port: 3306,
    user: 'root',
    password: 'root',
    database: 'medicine_test'
});

module.exports = {
    getPool: function (cb) {
        pool.getConnection((err, connection) => {
            if (err) {
                return cb(err);
            }
            cb(null, connection);
        });
    }
}