Flow

context-variable : key 변수명, value 엔티티명
iReslt는 사용자가 입력한 문장에 대한 intent 값을 갖고있다.
states 에서 플로우 이름 정의,
states-component : 컴포넌트 이름
states-properties : options나 사용할 변수 등을 지정

return에 자기자신하면 end flow